from django.db import models
from django.utils import timezone
from django.urls import reverse
from ckeditor.fields import RichTextField


# Create your models here.

##########################-about-page-##############################

class AboutPage(models.Model):
    image = models.ImageField(upload_to='')
    about_details = models.TextField()
    video_url = models.URLField()
    thought = models.TextField()
    name = models.CharField(max_length=255)
    designation = models.CharField(max_length=255)

    def __str__(self):
        return self.name

####################################-contauct-page-########################


class ContactUs_Page(models.Model):
    banner_image = models.ImageField(upload_to='')
    address = models.CharField(max_length=255)
    contact_number = models.CharField(max_length=20)
    email_id = models.EmailField()
    contact_image = models.ImageField(upload_to='')
    thought = models.TextField()
    contact_page_details = models.TextField()

    def __str__(self):
        return self.address

################################-contect-form-################################


class ContactFormSubmission(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15, blank=True)
    comments = models.TextField()

    def __str__(self):
        return self.name

########################-social-media-############################################


class SocialMediaLink(models.Model):
    facebook = models.URLField(max_length=200, blank=True, null=True)
    twitter = models.URLField(max_length=200, blank=True, null=True)
    instagram = models.URLField(max_length=200, blank=True, null=True)
    linkedin = models.URLField(max_length=200, blank=True, null=True)
    youtube = models.URLField(max_length=200, blank=True, null=True)

    def __str__(self):
        return f"Social Media Links for {self.id}"
    
###################################-terms-page-#####################################

class TermsPage(models.Model):
    terms_details = models.TextField()
    image = models.ImageField(upload_to='')
    thought = models.CharField(max_length=500)
    name = models.CharField(max_length=100)
    designation = models.CharField(max_length=100)

    def __str__(self):
        return "Terms & Conditions Page"
    
##################################--privacy-policy-##################################


class PrivacyPolicyPage(models.Model):
    privacy_details = models.TextField()
    video_url = models.URLField(blank=True, null=True)
    image = models.ImageField(upload_to='')
    thought = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    designation = models.CharField(max_length=255)

    def __str__(self):
        return "Privacy Policy Page"
    

######################################-category-name-###################################


class Category(models.Model):
    category_name = models.CharField(max_length=255)
    popular = models.BooleanField(default=False)

    def __str__(self):
        return self.category_name
    
    def get_absolute_url(self):
        return reverse('blog_category', args=[self.category_name])

###############################################-category meta- data-########################    

class CategoryMeta(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='meta_info')
    meta_title = models.CharField(max_length=150)
    meta_description = models.TextField()
    meta_keywords = models.TextField()
    h1_tag = models.CharField(max_length=100, blank=True, null=True)  

    def __str__(self):
        return f'Meta for {self.category.category_name}'


##########################################--video upload-###################################

class Video(models.Model):
    title = models.CharField(max_length=255)
    date = models.DateField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    video_link = models.URLField()
    image = models.ImageField(upload_to='')
    popular = models.BooleanField(default=False)
    profile_image = models.ImageField(upload_to='', blank=True, null=True)
    profile_name = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.title
    
############################################- author -#######################################################

class Author(models.Model):
    name = models.CharField(max_length=255)
    profile_image = models.ImageField(upload_to='', blank=True, null=True)
    bio = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name
    
#############################################--article--#####################################

class Article(models.Model):
    meta_title = models.CharField(max_length=255)
    meta_description = models.TextField()
    article_slug = models.SlugField(unique=True)
    meta_keywords = models.TextField()
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='articles', null=True, blank=True)
    article_title_h1 = models.CharField(max_length=255)
    categories = models.ManyToManyField(Category, related_name='articles')
    article_short_description = models.TextField()
    description = RichTextField(blank=True, null=True)
    article_thought = models.TextField(blank=True, null=True)
    banner_image_1 = models.ImageField(upload_to='')
    banner_image_2 = models.ImageField(upload_to='', blank=True, null=True)
    banner_image_3 = models.ImageField(upload_to='', blank=True, null=True)
    banner_image_4 = models.ImageField(upload_to='', blank=True, null=True)
    views = models.PositiveIntegerField(default=0)
    article_uploaded_date = models.DateTimeField(default=timezone.now)
    top_article = models.BooleanField(default=False)
    popular = models.BooleanField(default=False)
    best_in_categories = models.BooleanField(default=False)
    trending = models.BooleanField(default=False)
    hot_news = models.BooleanField(default=False)
    show_banner_on_front_page = models.BooleanField(default=False)
    active_status = models.BooleanField(default=True)

    def __str__(self):
        return self.article_title_h1
    
    def get_absolute_url(self):
        return reverse('blog_detail', args=[self.article_slug])

##################################################################################################
    
class ArticleDetails(models.Model):
    articledetailsid = models.AutoField(primary_key=True)
    articleid= models.ForeignKey(Article, on_delete=models.CASCADE)
    title = models.CharField(max_length=300)
    discription = RichTextField(blank=True, null=True)
    image = models.ImageField(upload_to='', blank=True, null=True)
    alt_text= models.CharField(max_length=200, blank=True, null=True)
   

    def __str__(self):
        return "||"+str(self.articledetailsid)+"||"+str(self.articleid)+"||"
    
##########################################----category--count---####################################

class CategoryArticleCount(models.Model):
    category_name = models.CharField(max_length=255)
    article_count = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.category_name}: {self.article_count}"
    
############################################-comment-###################################################

class Comment(models.Model):
    article = models.ForeignKey('Article', related_name='comments', on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    email = models.EmailField()
    body = models.TextField()
    created_on = models.DateTimeField(default=timezone.now)
    active = models.BooleanField(default=False)

    def __str__(self):
        return f'Comment by {self.name} on {self.article}'
    
#############################################-seo-#########################################################


class PageMeta(models.Model):
    page_name = models.CharField(max_length=100, null=True, blank=True)
    title = models.CharField(max_length=200, null=True, blank=True)
    meta_title = models.CharField(max_length=200, null=True, blank=True)
    meta_description = models.TextField(null=True, blank=True)
    meta_keywords = models.CharField(max_length=300, null=True, blank=True)
    canonical_url = models.URLField(null=True, blank=True)
    twitter_card = models.CharField(max_length=50, null=True, blank=True)
    twitter_site = models.CharField(max_length=100, null=True, blank=True)
    twitter_creator = models.CharField(max_length=100, null=True, blank=True)
    twitter_title = models.CharField(max_length=200, null=True, blank=True)
    twitter_image = models.URLField(null=True, blank=True)
    twitter_image_alt = models.CharField(max_length=100, null=True, blank=True)
    twitter_player = models.CharField(max_length=50, null=True, blank=True)
    twitter_player_width = models.IntegerField(null=True, blank=True)
    twitter_player_height = models.IntegerField(null=True, blank=True)
    og_title = models.CharField(max_length=200, null=True, blank=True)
    og_url = models.URLField(null=True, blank=True)
    og_image = models.URLField(null=True, blank=True)
    og_image_type = models.CharField(max_length=50, null=True, blank=True)
    og_image_width = models.IntegerField(null=True, blank=True)
    og_image_height = models.IntegerField(null=True, blank=True)
    og_type = models.CharField(max_length=50, null=True, blank=True)
    og_locale = models.CharField(max_length=20, null=True, blank=True)
    og_image_url = models.URLField(null=True, blank=True)
    og_image_secure_url = models.URLField(null=True, blank=True)
    og_site_name = models.CharField(max_length=200, null=True, blank=True)
    og_see_also = models.CharField(max_length=200, null=True, blank=True)
    article_author = models.CharField(max_length=200, null=True, blank=True)
    google_site_verification = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return self.page_name

##########################################--subscription--################################################

class Subscription(models.Model):
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email
    
#####################################-telegram-caht-id-####################################################

class TelegramSettings(models.Model):
    chat_id = models.CharField(max_length=100, help_text="Enter the chat ID for Telegram notifications")

    def __str__(self):
        return f"Telegram Chat ID: {self.chat_id}"
    

