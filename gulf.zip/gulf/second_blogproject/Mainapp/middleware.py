from django.http import HttpResponsePermanentRedirect
from django.utils.deprecation import MiddlewareMixin

class RedirectToWWWMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        host = request.get_host()
        if host == 'gulfarticles.com':
            new_host = 'www.gulfarticles.com'
            url = request.build_absolute_uri()
            url = url.replace(host, new_host)
            return HttpResponsePermanentRedirect(url)
        return self.get_response(request)

class HSTSMiddleware(MiddlewareMixin):
    def process_response(self, request, response):
        if hasattr(response, '__setitem__'):
            response['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        return response


