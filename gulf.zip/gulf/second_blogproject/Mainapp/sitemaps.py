from django.contrib.sitemaps import Sitemap
from django.urls import reverse
from django.conf import settings
import os
from .models import Article, Category

class StaticViewSitemap(Sitemap):
    priority = 0.5
    changefreq = 'yearly'

    def items(self):
        return [
            'index', 
            'about', 
            'contact_us', 
            'terms_and_conditions', 
            'privacy_policy', 
            'blog', 
            'interviews', 
            'news', 
            'videos'
        ]

    def location(self, item):
        return reverse(item)

class ArticleSitemap(Sitemap):
    changefreq = "daily"
    priority = 0.8

    def items(self):
        return Article.objects.all()

    def lastmod(self, obj):
        return obj.article_uploaded_date

class CategorySitemap(Sitemap):
    changefreq = "weekly"
    priority = 0.6

    def items(self):
        return Category.objects.all()

class MediaFilesSitemap(Sitemap):
    priority = 0.3
    changefreq = "yearly"

    def items(self):
        media_files = []
        for root, dirs, files in os.walk(settings.MEDIA_ROOT):
            for file in files:
                if file.endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp')):  # Add other extensions if needed
                    relative_path = os.path.relpath(os.path.join(root, file), settings.MEDIA_ROOT)
                    media_files.append(os.path.join(settings.MEDIA_URL, relative_path))
        return media_files

    def location(self, item):
        return item
