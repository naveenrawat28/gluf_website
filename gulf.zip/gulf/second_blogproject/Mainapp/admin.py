from django.contrib import admin
from .models import AboutPage, ContactUs_Page, ContactFormSubmission, SocialMediaLink,TermsPage ,PrivacyPolicyPage, Category, Video,Article,ArticleDetails, Comment, PageMeta,Subscription, TelegramSettings, CategoryMeta

admin.site.register(AboutPage)
admin.site.register(ContactUs_Page)
admin.site.register(SocialMediaLink)
admin.site.register(TermsPage)
admin.site.register(PrivacyPolicyPage)
admin.site.register(Category)
admin.site.register(Video)
admin.site.register(Article)
admin.site.register(ArticleDetails)
admin.site.register(Comment)
admin.site.register(PageMeta)
admin.site.register(Subscription)
admin.site.register(TelegramSettings)
admin.site.register(CategoryMeta)

class ContactFormSubmissionAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'comments')
    search_fields = ('name', 'email', 'phone')

admin.site.register(ContactFormSubmission, ContactFormSubmissionAdmin)
