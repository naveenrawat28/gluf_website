import json
import urllib.request
import urllib.parse
from django.conf import settings
from django.shortcuts import render,redirect
from .models import *
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from datetime import timedelta
from django.db.models import Count
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.core.paginator import Paginator
from django.http import HttpResponse
import requests
import threading


# Create your views here.

def get_meta(page_name):
    try:
        return PageMeta.objects.get(page_name=page_name)
    except PageMeta.DoesNotExist:
        return None

###########################################################################-----home_page------###########################################

def index(request):
    meta = get_meta('index')
    popular_categories = Category.objects.filter(popular=True)
    social_media_links = SocialMediaLink.objects.first()
    videos = Video.objects.filter(popular=True).order_by('-id')[:10]
    all_videos = Video.objects.all().order_by('-id')[:10]
    #hot_news
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    #banner
    banner_articles = Article.objects.filter(show_banner_on_front_page=True).order_by('-id')[:6]
    #top categories top_article
    top_articles = Article.objects.filter(top_article=True).exclude(categories__category_name='Digital-Magazines').order_by('-id')[:10]
    #intervie banner
    banner_show = Article.objects.filter(show_banner_on_front_page=True, categories__category_name='Digital-Magazines').order_by('-id')[:6]
    #top_interviews
    top_interviews = Article.objects.filter(top_article=True, categories__category_name='Digital-Magazines').order_by('-id')[:8]
    #popular
    popular_articles = Article.objects.filter(popular=True).order_by('-id')[:10]
    #recent
    recent_articles = Article.objects.all().order_by('-id')[:10]
    #best in category
    best_in_categories = Article.objects.filter(best_in_categories=True).order_by('-id')[:2]
    #next_best_in_categories
    next_best_in_categories = Article.objects.filter(best_in_categories=True).exclude(id__in=best_in_categories.values_list('id', flat=True)).order_by('-id')[:10]
    #top Trending News
    trending_news = Article.objects.filter(trending=True, categories__category_name='News').order_by('-id')[:10]
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")


    return render(request, 'index.html',{'popular_categories':popular_categories,'social_media_links':social_media_links,'videos': videos, 'all_videos': all_videos, 'hot_news_articles': hot_news_articles
                                         , 'banner_articles':banner_articles,'top_interviews': top_interviews, 'popular_articles':popular_articles, 'recent_articles':recent_articles, 'top_articles':top_articles,
                                        'best_in_categories':best_in_categories, 'trending_news':trending_news, 'next_best_in_categories':next_best_in_categories, 'banner_show':banner_show,
                                        'categories':categories, 'meta': meta})

###########################################################################-----about_page------###########################################

def about(request):
    meta = get_meta('about')
    about_page = AboutPage.objects.first()
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    return render(request, 'about.html',{'about_page': about_page,'social_media_links':social_media_links, 'hot_news_articles':hot_news_articles,'categories':categories,'meta': meta})

###########################################################################-----contact_page------###########################################

def contact_us(request):
    meta = get_meta('contact')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    contact_info = ContactUs_Page.objects.first()
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)

    if request.method == 'POST':
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        data = urllib.parse.urlencode(values).encode()
        req = urllib.request.Request(url, data=data)
        try:
            response = urllib.request.urlopen(req)
            result = json.loads(response.read().decode())
        except Exception as e:
            messages.error(request, 'Error verifying reCAPTCHA. Please try again later.')
            return render(request, 'contacts.html', {
                'contact_info': contact_info,
                'social_media_links': social_media_links,
                'hot_news_articles': hot_news_articles,
                'categories': categories,
                'meta': meta
            })

        if result.get('success'):
            name = request.POST.get('name')
            email = request.POST.get('email')
            phone = request.POST.get('phone')
            comments = request.POST.get('comments')
            if name and email and comments:
                ContactFormSubmission.objects.create(
                    name=name,
                    email=email,
                    phone=phone,
                    comments=comments
                )

                telegram_settings = TelegramSettings.objects.all()
                bot_token = settings.TELEGRAM_BOT_TOKEN
                telegram_message = (
                    "📬 *New Contact Query Submitted!* 📝\n\n"
                    f"👤 *Name:* {name}\n"
                    f"📧 *Email:* {email}\n"
                    f"📱 *Phone:* {phone}\n"
                    f"💬 *Message:* {comments}\n\n"
                    "🔔 *Please check and respond accordingly.*"
                )

                chat_ids = [setting.chat_id for setting in telegram_settings]
                threading.Thread(target=send_notifications_in_background, args=(telegram_message, bot_token, chat_ids)).start()

                messages.success(request, 'Your message has been sent successfully! 🎉')
            else:
                messages.warning(request, 'There was an error sending your message. Please make sure all required fields are filled out.')
        else:
            messages.warning(request, 'reCAPTCHA verification failed. Please try again.')

    return render(request, 'contacts.html', {
        'contact_info': contact_info,
        'social_media_links': social_media_links,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta
    })


def send_telegram_notification(message, bot_token, chat_id):
    send_text = f'https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={urllib.parse.quote(message)}&parse_mode=Markdown'
    requests.get(send_text)

def send_notifications_in_background(message, bot_token, chat_ids):
    for chat_id in chat_ids:
        thread = threading.Thread(target=send_telegram_notification, args=(message, bot_token, chat_id))
        thread.start()


##########################################################################-----terms-----page--##########################################

def terms_and_conditions(request):
    meta = get_meta('terms_and_conditions')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    terms_page = TermsPage.objects.first()
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    return render(request, 'terms_and_conditions.html', {'terms_page': terms_page,'social_media_links':social_media_links,'hot_news_articles':hot_news_articles,'categories':categories,'meta': meta})

########################################################################--privacy-policy-################################################

def privacy_policy(request):
    meta = get_meta('privacy_policy')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    privacy_policy_page = PrivacyPolicyPage.objects.first()
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    return render(request, 'privacy_policy.html', {'privacy_policy_page': privacy_policy_page, 'social_media_links':social_media_links,'hot_news_articles':hot_news_articles,'categories':categories,'meta': meta})


###########################################################################--count-category--############################################

def update_category_article_count():
    CategoryArticleCount.objects.all().delete()  # Clear previous counts

    categories_with_article_count = Category.objects.annotate(article_count=Count('articles'))

    for category in categories_with_article_count:
        CategoryArticleCount.objects.create(
            category_name=category.category_name,
            article_count=category.article_count
        )
        
###########################################################################-----blog_page------###########################################

def blog(request):
    meta = get_meta('blog')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    social_media_links = SocialMediaLink.objects.first()
    popular_categories = Category.objects.filter(popular=True)
    
    articles = Article.objects.exclude(categories__category_name__in=['Digital-Magazines', 'News']).order_by('-id')

    # Update category article counts
    update_category_article_count()
    category_article_counts = CategoryArticleCount.objects.all()

    paginator = Paginator(articles, 10)  
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            banner_image_url = article.banner_image_1.url if article.banner_image_1 else ""
            category_name = article.categories.all()[0].category_name if article.categories.exists() else ""

            articles_html += f"""
            <div class="list-post fl-wrap">
                <div class="list-post-media">
                    <a href="/{article.article_slug}/">
                        <div class="bg-wrap">
                            <div class="bg" data-bg="{banner_image_url}"></div>
                        </div>
                    </a>
                    <span class="post-media_title">&copy; {article.article_title_h1}</span>
                </div>
                <div class="list-post-content">
                    <a class="post-category-marker" href="/category/{category_name}/">{category_name}</a>
                    <h3><a href="/{article.article_slug}/">{article.article_title_h1}</a></h3>
                    <span class="post-date"><i class="far fa-clock"></i> {article.article_uploaded_date.strftime('%d %b %Y')}</span>
                    <p>{article.article_short_description}</p>
                    <ul class="post-opt">
                        <li><i class="fal fa-eye"></i> {article.views}</li>
                    </ul>
                    <div class="author-link">
                        <a href="#">
                            <img src="{article.author_profile_image.url if article.author_profile_image else ''}" alt="">
                            <span>By {article.author_name}</span>
                        </a>
                    </div>
                </div>
            </div>
            """
        has_next = page_obj.has_next()
        return JsonResponse({'html': articles_html, 'has_next': has_next})

    # For the initial page load
    popular_articles = Article.objects.filter(popular=True).exclude(categories__category_name__in=['News', 'Digital-Magazines']).order_by('-id')[:10]
    recent_articles = Article.objects.exclude(categories__category_name__in=['News', 'Digital-Magazines']).order_by('-id')[:10]

    context = {
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'category_article_counts': category_article_counts, 
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta,
        'articles': page_obj
    }
    return render(request, 'blog.html', context)


#########################################################################-Interviews-page-###############################################################

def interviews(request):
    meta = get_meta('interviews')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    social_media_links = SocialMediaLink.objects.first()
    popular_categories = Category.objects.filter(popular=True)
    articles = Article.objects.filter(categories__category_name='Digital-Magazines').order_by('-id')
    category_article_counts = CategoryArticleCount.objects.all()

    # Pagination setup
    paginator = Paginator(articles, 10)  
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            banner_image_url = article.banner_image_1.url if article.banner_image_1 else ""
            category_name = article.categories.all()[0].category_name if article.categories.exists() else ""

            articles_html += f"""
            <div class="list-post fl-wrap">
                <div class="list-post-media">
                    <a href="/{article.article_slug}/">
                        <div class="bg-wrap">
                            <div class="bg" data-bg="{banner_image_url}"></div>
                        </div>
                    </a>
                    <span class="post-media_title">&copy; {article.article_title_h1}</span>
                </div>
                <div class="list-post-content">
                    <a class="post-category-marker" href="/category/{category_name}/">{category_name}</a>
                    <h3><a href="/{article.article_slug}/">{article.article_title_h1}</a></h3>
                    <span class="post-date"><i class="far fa-clock"></i> {article.article_uploaded_date.strftime('%d %b %Y')}</span>
                    <p>{article.article_short_description}</p>
                    <ul class="post-opt">
                        <li><i class="fal fa-eye"></i> {article.views}</li>
                    </ul>
                    <div class="author-link">
                        <a href="#">
                            <img src="{article.author_profile_image.url if article.author_profile_image else ''}" alt="">
                            <span>By {article.author_name}</span>
                        </a>
                    </div>
                </div>
            </div>
            """
        has_next = page_obj.has_next()
        return JsonResponse({'html': articles_html, 'has_next': has_next})

    popular_articles = Article.objects.filter(popular=True, categories__category_name='Digital-Magazines').order_by('-id')[:10]
    recent_articles = Article.objects.filter(categories__category_name='Digital-Magazines').order_by('-id')[:10]

    context = {
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta,
        'articles': page_obj  # Pass paginated articles to the template
    }
    return render(request, 'interviews.html', context)

##########################################################################---news-page----#########################################################

def news(request):
    meta = get_meta('news')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    social_media_links = SocialMediaLink.objects.first()
    popular_categories = Category.objects.filter(popular=True)
    articles = Article.objects.filter(categories__category_name='News').order_by('-id')
    category_article_counts = CategoryArticleCount.objects.all()

    paginator = Paginator(articles, 10)  # Show 10 articles per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            banner_image_url = article.banner_image_1.url if article.banner_image_1 else ""
            category_name = article.categories.all()[0].category_name if article.categories.exists() else ""

            articles_html += f"""
            <div class="list-post fl-wrap">
                <div class="list-post-media">
                    <a href="/{article.article_slug}/">
                        <div class="bg-wrap">
                            <div class="bg" data-bg="{banner_image_url}"></div>
                        </div>
                    </a>
                    <span class="post-media_title">&copy; {article.article_title_h1}</span>
                </div>
                <div class="list-post-content">
                    <a class="post-category-marker" href="/category/{category_name}/">{category_name}</a>
                    <h3><a href="/{article.article_slug}/">{article.article_title_h1}</a></h3>
                    <span class="post-date"><i class="far fa-clock"></i> {article.article_uploaded_date.strftime('%d %b %Y')}</span>
                    <p>{article.article_short_description}</p>
                    <ul class="post-opt">
                        <li><i class="fal fa-eye"></i> {article.views}</li>
                    </ul>
                    <div class="author-link">
                        <a href="#">
                            <img src="{article.author_profile_image.url if article.author_profile_image else ''}" alt="">
                            <span>By {article.author_name}</span>
                        </a>
                    </div>
                </div>
            </div>
            """
        has_next = page_obj.has_next()
        return JsonResponse({'html': articles_html, 'has_next': has_next})

    # For the initial page load
    popular_articles = Article.objects.filter(popular=True, categories__category_name='News').order_by('-id')[:10]
    recent_articles = Article.objects.filter(categories__category_name='News').order_by('-id')[:10]

    context = {
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta,
        'articles': page_obj  # Pass the paginated articles
    }
    return render(request, 'news.html', context)

###########################################################################-----blog_page_category------###########################################

def blog_category(request, name):
    # Fetch global meta as you currently do
    meta = get_meta('blog_category')
    
    # Fetch category-specific meta information and store it separately
    category = get_object_or_404(Category, category_name=name)
    category_meta = CategoryMeta.objects.filter(category=category).first()

    # Your existing logic remains the same
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    social_media_links = SocialMediaLink.objects.first()
    articles = Article.objects.filter(categories=category).order_by('-id')

    paginator = Paginator(articles, 10)  # Show 10 articles per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            banner_image_url = article.banner_image_1.url if article.banner_image_1 else ""
            category_name = article.categories.all()[0].category_name if article.categories.exists() else ""

            articles_html += f"""
            <div class="list-post fl-wrap">
                <div class="list-post-media">
                    <a href="/{article.article_slug}/">
                        <div class="bg-wrap">
                            <div class="bg" data-bg="{banner_image_url}"></div>
                        </div>
                    </a>
                    <span class="post-media_title">&copy; {article.article_title_h1}</span>
                </div>
                <div class="list-post-content">
                    <a class="post-category-marker" href="/category/{category_name}/">{category_name}</a>
                    <h3><a href="/{article.article_slug}/">{article.article_title_h1}</a></h3>
                    <span class="post-date"><i class="far fa-clock"></i> {article.article_uploaded_date.strftime('%d %b %Y')}</span>
                    <p>{article.article_short_description}</p>
                    <ul class="post-opt">
                        <li><i class="fal fa-eye"></i> {article.views}</li>
                    </ul>
                    <div class="author-link">
                        <a href="#">
                            <img src="{article.author_profile_image.url if article.author_profile_image else ''}" alt="">
                            <span>By {article.author_name}</span>
                        </a>
                    </div>
                </div>
            </div>
            """
        has_next = page_obj.has_next()
        return JsonResponse({'html': articles_html, 'has_next': has_next})

    # Other context variables
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    category_article_counts = CategoryArticleCount.objects.all()
    popular_categories = Category.objects.filter(popular=True)
    popular_articles = Article.objects.filter(popular=True).order_by('-id')[:10]
    recent_articles = Article.objects.all().order_by('-id')[:10]
    article_details = ArticleDetails.objects.filter(articleid__in=articles)

    # Return the response with the updated context, passing category_meta as a separate variable
    return render(request, 'blog2.html', {
        'hot_news_articles': hot_news_articles,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'popular_categories': popular_categories,
        'category': category,
        'articles': page_obj, 
        'categories': categories,
        'social_media_links': social_media_links,
        'article_details': article_details,
        'meta': meta,  # Pass the global meta as before
        'category_meta': category_meta  # Pass the category-specific meta separately
    })


###########################################################################-----blog_details_page------###########################################

def blog_detail(request, slug):
    meta = get_meta('blog_detail')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)

    # Categories
    category_article_counts = CategoryArticleCount.objects.all()
    # Popular categories
    popular_categories = Category.objects.filter(popular=True)
    # Popular articles
    popular_articles = Article.objects.filter(popular=True).order_by('-id')[:10]
    # Recent articles
    recent_articles = Article.objects.all().order_by('-id')[:10]
    # Get the article by slug
    article = get_object_or_404(Article, article_slug=slug)
    # Increment the views count
    article.views += 1
    article.save()

    # Related articles
    related_articles = Article.objects.filter(
        categories__in=article.categories.all()
    ).exclude(id=article.id).distinct().order_by('-id')[:10]

    comments = article.comments.filter(active=True)
    comment_count = comments.count()
    new_comment = None
    success_message = None

    if request.method == 'POST':
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        data = urllib.parse.urlencode(values).encode()
        req = urllib.request.Request(url, data=data)
        response = urllib.request.urlopen(req)
        result = json.loads(response.read().decode())

        if result['success']:
            name = request.POST.get('name')
            email = request.POST.get('email')
            body = request.POST.get('body')
            
            if name and email and body:
                new_comment = Comment(
                    article=article,
                    name=name,
                    email=email,
                    body=body,
                )
                new_comment.save()

                telegram_settings = TelegramSettings.objects.all()
                bot_token = settings.TELEGRAM_BOT_TOKEN

                # Format the message with emojis and markdown
                telegram_message = (
                    f"📝 *New Comment on Blog:*\n\n"
                    f"🔗 *Blog Title:* {article.article_title_h1}\n"
                    f"👤 *Name:* {name}\n"
                    f"📧 *Email:* {email}\n"
                    f"💬 *Comment:* {body}\n\n"
                    "✅ *Please review and approve if appropriate.*"
                )

                # Send notifications in the background using threads
                chat_ids = [setting.chat_id for setting in telegram_settings]
                threading.Thread(target=send_comment_notifications_in_background, args=(telegram_message, bot_token, chat_ids)).start()

                messages.success(request, 'Your comment has been submitted and will appear after approval.')
                return HttpResponseRedirect(reverse('blog_detail', args=[slug]))
        else:
            messages.warning(request, 'reCAPTCHA verification failed. Please try again.')

    return render(request, 'blog-detail.html', {
        'hot_news_articles': hot_news_articles,
        'article': article,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'categories': categories,
        'related_articles': related_articles,
        'comments': comments,
        'comment_count': comment_count,
        'new_comment': new_comment,
        'meta': meta,
        'success_message': success_message
    })


def send_telegram_notification_comment(message, bot_token, chat_id):
    send_text = f'https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={urllib.parse.quote(message)}&parse_mode=Markdown'
    requests.get(send_text)

def send_comment_notifications_in_background(message, bot_token, chat_ids):
    for chat_id in chat_ids:
        thread = threading.Thread(target=send_telegram_notification_comment, args=(message, bot_token, chat_id))
        thread.start()

##########################################################################-----video-page-----#####################################################

def video(request):
    meta = get_meta('video')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    social_media_links = SocialMediaLink.objects.first()
    videos = Video.objects.all().order_by('-date')[:20]
    recent_videos = Video.objects.all().order_by('-id')[:10]
    popular_videos = Video.objects.filter(popular=True).order_by('-id')[:10]
    return render(request, 'video.html',{'social_media_links':social_media_links,'videos': videos, 'recent_videos':recent_videos,'popular_videos':popular_videos,
                                         'hot_news_articles':hot_news_articles,'categories':categories, 'meta': meta})


#####################################################################--load--more--#################################################################

def load_more_videos(request):
    offset = int(request.GET.get('offset', 20))
    limit = 10
    videos = Video.objects.all()[offset:offset+limit]
    video_data = [
        {
            'video_link': video.video_link,
            'image_url': video.image.url,
            'title': video.title,
            'description': video.description,
            'category': video.category,
            'date': video.date.strftime("%d %B %Y"),
            'profile_image_url': video.profile_image.url,
            'profile_name': video.profile_name,
        } for video in videos
    ]
    return JsonResponse({'videos': video_data,})

##################################################-search--page###########################################################

def search(request):
    meta = get_meta('search_result')
    categories = CategoryArticleCount.objects.exclude(category_name="Digital-Magazines")
    query = request.GET.get('se', '')
    if query:
        results = Article.objects.filter(article_title_h1__icontains=query)
    else:
        results = Article.objects.none()
    #popular_articles
    popular_articles = Article.objects.filter(popular=True).order_by('-id')[:10]
    #recent_articles
    recent_articles = Article.objects.order_by('-id')[:10]
    #category_count
    category_article_counts = CategoryArticleCount.objects.all()
    #hot
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago)
    #popular_categories
    popular_categories = Category.objects.filter(popular=True)
    #social_media
    social_media_links = SocialMediaLink.objects.first()

    return render(request, 'search_results.html', {'results': results, 'query': query, 'popular_articles':popular_articles, 'recent_articles':recent_articles,
                                                   'hot_news_articles':hot_news_articles, 'category_article_counts':category_article_counts, 'popular_categories':popular_categories,
                                                   'social_media_links':social_media_links,'categories':categories,'meta': meta})


########################################################--subscription--#########################################################################


def subscribe(request):
    today = timezone.now().date()
    last_submission_date = request.session.get('last_submission_date')

    if last_submission_date and last_submission_date == str(today):
        messages.error(request, 'You have already submitted the form today. If you want to add another email, please wait until tomorrow.')
        return redirect(request.META.get('HTTP_REFERER', 'index'))

    if request.method == 'POST':
        email = request.POST.get('email', '').strip()

        if not email:
            messages.error(request, 'Email field cannot be empty.')
        else:
            if Subscription.objects.filter(email=email).exists():
                messages.error(request, 'This email has already been submitted.')
            else:
                Subscription.objects.create(email=email)
                messages.success(request, 'We will be in touch soon!')
                request.session['last_submission_date'] = str(today)
                request.session.set_expiry(86400) 
        
        return redirect(request.META.get('HTTP_REFERER', 'index'))

    return redirect('index')

##########################################################################################################################

def custom_404(request, exception):
    return render(request, '404.html', {}, status=404)

def custom_500(request):
    return render(request, '500.html', status=500)

#########################################-robots.txt-#######################################################################


def robots_txt(request):
    content = """
    User-agent: *
    Disallow: /admin/
    Allow: /

    Sitemap: https://www.gulfarticles.com/sitemap.xml
    """
    return HttpResponse(content, content_type="text/plain")