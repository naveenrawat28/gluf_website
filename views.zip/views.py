import json
import urllib.request
import urllib.parse
from django.conf import settings
from django.shortcuts import render,redirect
from .models import *
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from datetime import timedelta
from django.db.models import Count
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.core.paginator import Paginator
from django.http import HttpResponse
import requests
import threading
from itertools import zip_longest

# Create your views here.

def get_meta(page_name):
    try:
        return PageMeta.objects.get(page_name=page_name)
    except PageMeta.DoesNotExist:
        return None

###########################################################################-----home_page------###########################################


def index(request):
    meta = get_meta('index')
    popular_categories = Category.objects.filter(popular=True)
    social_media_links = SocialMediaLink.objects.first()
    videos = Video.objects.filter(popular=True).order_by('-id')[:10]
    all_videos = Video.objects.all().order_by('-id')[:10]

    # Hot news articles (active only)
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)

    # Banner articles (active only)
    banner_articles = Article.objects.filter(show_banner_on_front_page=True, active_status=True).order_by('-article_uploaded_date')[:6]
    banner_articles_next_four = Article.objects.filter(show_banner_on_front_page=True, active_status=True).order_by('-article_uploaded_date')[6:10]

    # Top articles (active only)
    top_articles = Article.objects.filter(top_article=True, active_status=True).exclude(categories__category_name='Exclusive-Features').order_by('-article_uploaded_date')[:10]

    # Interview banner (active only)
    banner_show = Article.objects.filter(show_banner_on_front_page=True, categories__category_name='Exclusive-Features', active_status=True).order_by('-article_uploaded_date')[:6]

    # Top interviews (active only)
    top_interviews = Article.objects.filter(top_article=True, categories__category_name='Exclusive-Features', active_status=True).order_by('-article_uploaded_date')[:8]

    # Popular articles (active only)
    popular_articles = Article.objects.filter(popular=True, active_status=True).order_by('-article_uploaded_date')[:10]

    # Recent articles (active only)
    recent_articles = Article.objects.filter(active_status=True).order_by('-article_uploaded_date')[:10]

    # Best in categories (active only)
    best_in_categories = Article.objects.filter(best_in_categories=True, active_status=True).order_by('-article_uploaded_date')[:2]
    next_best_in_categories = Article.objects.filter(best_in_categories=True, active_status=True).exclude(id__in=best_in_categories.values_list('id', flat=True)).order_by('-article_uploaded_date')[:10]

    # Trending news (active only)
    trending_news = Article.objects.filter(trending=True, categories__category_name='News', active_status=True).order_by('-article_uploaded_date')[:10]

    # Recent Top Magazine Articles (active only)
    recent_magazine_articles = Article.objects.filter(
        magazine_iframe__isnull=False,
        magazine_thumbnail__isnull=False,
        magazine_name__isnull=False,
        active_status=True
    ).order_by('-article_uploaded_date')[:10]

    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")

    return render(request, 'index.html', {
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'videos': videos,
        'all_videos': all_videos,
        'hot_news_articles': hot_news_articles,
        'banner_articles': banner_articles,
        'top_interviews': top_interviews,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'top_articles': top_articles,
        'best_in_categories': best_in_categories,
        'trending_news': trending_news,
        'next_best_in_categories': next_best_in_categories,
        'banner_show': banner_show,
        'categories': categories,
        'banner_articles_next_four': banner_articles_next_four,
        'meta': meta,
        'recent_magazine_articles': recent_magazine_articles,  # Added here
    })


###########################################################################-----about_page------###########################################


def about(request):
    meta = get_meta('about')
    about_page = AboutPage.objects.first()
    social_media_links = SocialMediaLink.objects.first()
    
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)
    
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")

    return render(request, 'about.html', {
        'about_page': about_page,
        'social_media_links': social_media_links,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta
    })

###########################################################################-----contact_page------###########################################

def contact_us(request):
    meta = get_meta('contact')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    contact_info = ContactUs_Page.objects.first()
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)

    if request.method == 'POST':
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        data = urllib.parse.urlencode(values).encode()
        req = urllib.request.Request(url, data=data)
        try:
            response = urllib.request.urlopen(req)
            result = json.loads(response.read().decode())
        except Exception as e:
            messages.error(request, 'Error verifying reCAPTCHA. Please try again later.')
            return render(request, 'contacts.html', {
                'contact_info': contact_info,
                'social_media_links': social_media_links,
                'hot_news_articles': hot_news_articles,
                'categories': categories,
                'meta': meta
            })

        if result.get('success'):
            name = request.POST.get('name')
            email = request.POST.get('email')
            phone = request.POST.get('phone')
            comments = request.POST.get('comments')
            if name and email and comments:
                ContactFormSubmission.objects.create(
                    name=name,
                    email=email,
                    phone=phone,
                    comments=comments
                )

                telegram_settings = TelegramSettings.objects.all()
                bot_token = settings.TELEGRAM_BOT_TOKEN
                telegram_message = (
                    "📬 *New Contact Query Submitted!* 📝\n\n"
                    f"👤 *Name:* {name}\n"
                    f"📧 *Email:* {email}\n"
                    f"📱 *Phone:* {phone}\n"
                    f"💬 *Message:* {comments}\n\n"
                    "🔔 *Please check and respond accordingly.*"
                )

                chat_ids = [setting.chat_id for setting in telegram_settings]
                threading.Thread(target=send_notifications_in_background, args=(telegram_message, bot_token, chat_ids)).start()

                messages.success(request, 'Your message has been sent successfully! 🎉')
            else:
                messages.warning(request, 'There was an error sending your message. Please make sure all required fields are filled out.')
        else:
            messages.warning(request, 'reCAPTCHA verification failed. Please try again.')

    return render(request, 'contacts.html', {
        'contact_info': contact_info,
        'social_media_links': social_media_links,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta
    })


def send_telegram_notification(message, bot_token, chat_id):
    send_text = f'https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={urllib.parse.quote(message)}&parse_mode=Markdown'
    requests.get(send_text)

def send_notifications_in_background(message, bot_token, chat_ids):
    for chat_id in chat_ids:
        thread = threading.Thread(target=send_telegram_notification, args=(message, bot_token, chat_id))
        thread.start()


##########################################################################-----terms-----page--##########################################

def terms_and_conditions(request):
    meta = get_meta('terms_and_conditions')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    terms_page = TermsPage.objects.first()
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)
    return render(request, 'terms_and_conditions.html', {'terms_page': terms_page,'social_media_links':social_media_links,'hot_news_articles':hot_news_articles,'categories':categories,'meta': meta})

########################################################################--privacy-policy-################################################

def privacy_policy(request):
    meta = get_meta('privacy_policy')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    privacy_policy_page = PrivacyPolicyPage.objects.first()
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)
    return render(request, 'privacy_policy.html', {'privacy_policy_page': privacy_policy_page, 'social_media_links':social_media_links,'hot_news_articles':hot_news_articles,'categories':categories,'meta': meta})


###########################################################################--count-category--############################################

def update_category_article_count():
    CategoryArticleCount.objects.all().delete()  # Clear previous counts
    categories_with_article_count = Category.objects.annotate(article_count=Count('articles'))

    for category in categories_with_article_count:
        CategoryArticleCount.objects.create(
            category_name=category.category_name,
            article_count=category.article_count
        )
        
###########################################################################-----blog_page------###########################################

def blog(request):
    meta = get_meta('blog')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)
    social_media_links = SocialMediaLink.objects.first()
    popular_categories = Category.objects.filter(popular=True)
    
    # Filter articles where active_status=True
    articles = Article.objects.filter(active_status=True).exclude(categories__category_name__in=['Exclusive-Features', 'News']).order_by('-article_uploaded_date')

    # Update category article counts
    update_category_article_count()
    category_article_counts = CategoryArticleCount.objects.all()

    paginator = Paginator(articles, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            banner_image_url = article.banner_image_1.url if article.banner_image_1 else ""
            category_name = article.categories.all()[0].category_name if article.categories.exists() else ""

            # Truncate article_short_description to 200 characters
            short_description = article.article_short_description[:190]
            if len(article.article_short_description) > 190:
                short_description += "..."

            # Update author details using the Author model
            author_profile_image_url = article.author.profile_image.url if article.author.profile_image else ''
            author_name = article.author.name

            articles_html += f"""
            <div class="list-post fl-wrap">
                <div class="list-post-media">
                    <a href="/{article.article_slug}/">
                        <div class="bg-wrap">
                            <div class="bg" data-bg="{banner_image_url}"></div>
                        </div>
                    </a>
                    <span class="post-media_title">&copy; {article.article_title_h1}</span>
                </div>
                <div class="list-post-content">
                    <a class="post-category-marker" href="/category/{category_name}/">{category_name}</a>
                    <h3><a href="/{article.article_slug}/">{article.article_title_h1}</a></h3>
                    <span class="post-date"><i class="far fa-clock"></i> {article.article_uploaded_date.strftime('%d %b %Y')}</span>
                    <p>{short_description}</p>
                    <ul class="post-opt">
                        <li><i class="fal fa-eye"></i> {article.views}</li>
                    </ul>
                    <div class="author-link">
                        <a href="#">
                            <img src="{author_profile_image_url}" alt="">
                            <span>By {author_name}</span>
                        </a>
                    </div>
                </div>
            </div>
            """
        has_next = page_obj.has_next()
        return JsonResponse({'html': articles_html, 'has_next': has_next})

    # For the initial page load
    popular_articles = Article.objects.filter(popular=True, active_status=True).exclude(categories__category_name__in=['News', 'Exclusive-Features']).order_by('-article_uploaded_date')[:10]
    recent_articles = Article.objects.filter(active_status=True).exclude(categories__category_name__in=['News', 'Exclusive-Features']).order_by('-article_uploaded_date')[:10]

    context = {
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta,
        'articles': page_obj
    }
    return render(request, 'blog.html', context)

#########################################################################-Interviews-page-###############################################################


def interviews(request):
    meta = get_meta('interviews')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)
    social_media_links = SocialMediaLink.objects.first()
    popular_categories = Category.objects.filter(popular=True)
    
    # Filter only active articles
    articles = Article.objects.filter(categories__category_name='Exclusive-Features', active_status=True).order_by('-article_uploaded_date')
    category_article_counts = CategoryArticleCount.objects.all()

    # Pagination setup
    paginator = Paginator(articles, 20)  
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            banner_image_url = article.banner_image_1.url if article.banner_image_1 else ""
            category_name = article.categories.all()[0].category_name if article.categories.exists() else ""

            # Truncate article_short_description to 190 characters
            short_description = article.article_short_description[:190]
            if len(article.article_short_description) > 190:
                short_description += "..."

            # Fetch author details using the Author model
            author_profile_image_url = article.author.profile_image.url if article.author.profile_image else ''
            author_name = article.author.name

            articles_html += f"""
            <div class="list-post fl-wrap">
                <div class="list-post-media">
                    <a href="/{article.article_slug}/">
                        <div class="bg-wrap">
                            <div class="bg" data-bg="{banner_image_url}"></div>
                        </div>
                    </a>
                    <span class="post-media_title">&copy; {article.article_title_h1}</span>
                </div>
                <div class="list-post-content">
                    <a class="post-category-marker" href="/category/{category_name}/">{category_name}</a>
                    <h3><a href="/{article.article_slug}/">{article.article_title_h1}</a></h3>
                    <span class="post-date"><i class="far fa-clock"></i> {article.article_uploaded_date.strftime('%d %b %Y')}</span>
                    <p>{short_description}</p>
                    <ul class="post-opt">
                        <li><i class="fal fa-eye"></i> {article.views}</li>
                    </ul>
                    <div class="author-link">
                        <a href="#">
                            <img src="{author_profile_image_url}" alt="{author_name}">
                            <span>By {author_name}</span>
                        </a>
                    </div>
                </div>
            </div>
            """
        has_next = page_obj.has_next()
        return JsonResponse({'html': articles_html, 'has_next': has_next})

    # For the initial page load
    popular_articles = Article.objects.filter(popular=True, categories__category_name='Exclusive-Features', active_status=True).order_by('-article_uploaded_date')[:10]
    recent_articles = Article.objects.filter(categories__category_name='Exclusive-Features', active_status=True).order_by('-article_uploaded_date')[:10]

    context = {
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta,
        'articles': page_obj  # Pass paginated articles to the template
    }
    return render(request, 'interviews.html', context)

##########################################################################---news-page----#########################################################

def news(request):
    meta = get_meta('news')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)
    social_media_links = SocialMediaLink.objects.first()
    popular_categories = Category.objects.filter(popular=True)
    
    # Filter articles with active_status=True
    articles = Article.objects.filter(categories__category_name='News', active_status=True).order_by('-article_uploaded_date')
    category_article_counts = CategoryArticleCount.objects.all()

    paginator = Paginator(articles, 20)  # Show 10 articles per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            banner_image_url = article.banner_image_1.url if article.banner_image_1 else ""
            category_name = article.categories.all()[0].category_name if article.categories.exists() else ""

            # Truncate article_short_description to 190 characters
            short_description = article.article_short_description[:190]
            if len(article.article_short_description) > 190:
                short_description += "..."

            # Update to use the Author model fields
            author_profile_image_url = article.author.profile_image.url if article.author.profile_image else ''
            author_name = article.author.name

            articles_html += f"""
            <div class="list-post fl-wrap">
                <div class="list-post-media">
                    <a href="/{article.article_slug}/">
                        <div class="bg-wrap">
                            <div class="bg" data-bg="{banner_image_url}"></div>
                        </div>
                    </a>
                    <span class="post-media_title">&copy; {article.article_title_h1}</span>
                </div>
                <div class="list-post-content">
                    <a class="post-category-marker" href="/category/{category_name}/">{category_name}</a>
                    <h3><a href="/{article.article_slug}/">{article.article_title_h1}</a></h3>
                    <span class="post-date"><i class="far fa-clock"></i> {article.article_uploaded_date.strftime('%d %b %Y')}</span>
                    <p>{short_description}</p>
                    <ul class="post-opt">
                        <li><i class="fal fa-eye"></i> {article.views}</li>
                    </ul>
                    <div class="author-link">
                        <a href="#">
                            <img src="{author_profile_image_url}" alt="{author_name}">
                            <span>By {author_name}</span>
                        </a>
                    </div>
                </div>
            </div>
            """
        has_next = page_obj.has_next()
        return JsonResponse({'html': articles_html, 'has_next': has_next})

    # For the initial page load
    popular_articles = Article.objects.filter(popular=True, categories__category_name='News', active_status=True).order_by('-article_uploaded_date')[:10]
    recent_articles = Article.objects.filter(categories__category_name='News', active_status=True).order_by('-article_uploaded_date')[:10]

    context = {
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'hot_news_articles': hot_news_articles,
        'categories': categories,
        'meta': meta,
        'articles': page_obj  # Pass the paginated articles
    }
    return render(request, 'news.html', context)

###########################################################################-----blog_page_category------###########################################

from django.shortcuts import redirect

def blog_category(request, name):
    # 🔁 Redirect to lowercase URL if current is not lowercase
    if name != name.lower():
        return redirect('blog_category', name=name.lower(), permanent=True)

    meta = get_meta('blog_category')
    category = get_object_or_404(Category, category_name__iexact=name)  
    category_meta = CategoryMeta.objects.filter(category=category).first()

    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    social_media_links = SocialMediaLink.objects.first()

    # Filter only articles with active_status=True
    articles = Article.objects.filter(categories=category, active_status=True).order_by('-article_uploaded_date')

    paginator = Paginator(articles, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            banner_image_url = article.banner_image_1.url if article.banner_image_1 else ""
            category_name = article.categories.all()[0].category_name if article.categories.exists() else ""

            short_description = article.article_short_description[:190]
            if len(article.article_short_description) > 190:
                short_description += "..."

            author_profile_image_url = article.author.profile_image.url if article.author.profile_image else ''
            author_name = article.author.name

            articles_html += f"""
            <div class="list-post fl-wrap">
                <div class="list-post-media">
                    <a href="/{article.article_slug}/">
                        <div class="bg-wrap">
                            <div class="bg" data-bg="{banner_image_url}"></div>
                        </div>
                    </a>
                    <span class="post-media_title">&copy; {article.article_title_h1}</span>
                </div>
                <div class="list-post-content">
                    <a class="post-category-marker" href="/category/{category_name.lower()}/">{category_name}</a>
                    <h3><a href="/{article.article_slug}/">{article.article_title_h1}</a></h3>
                    <span class="post-date"><i class="far fa-clock"></i> {article.article_uploaded_date.strftime('%d %b %Y')}</span>
                    <p>{short_description}</p>
                    <ul class="post-opt">
                        <li><i class="fal fa-eye"></i> {article.views}</li>
                    </ul>
                    <div class="author-link">
                        <a href="#">
                            <img src="{author_profile_image_url}" alt="{author_name}">
                            <span>By {author_name}</span>
                        </a>
                    </div>
                </div>
            </div>
            """
        has_next = page_obj.has_next()
        return JsonResponse({'html': articles_html, 'has_next': has_next})

    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)
    category_article_counts = CategoryArticleCount.objects.all()
    popular_categories = Category.objects.filter(popular=True)
    popular_articles = Article.objects.filter(popular=True, active_status=True).order_by('-article_uploaded_date')[:10]
    recent_articles = Article.objects.filter(active_status=True).order_by('-article_uploaded_date')[:10]
    article_details = ArticleDetails.objects.filter(articleid__in=articles)

    return render(request, 'blog2.html', {
        'hot_news_articles': hot_news_articles,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'popular_categories': popular_categories,
        'category': category,
        'articles': page_obj,
        'categories': categories,
        'social_media_links': social_media_links,
        'article_details': article_details,
        'meta': meta,
        'category_meta': category_meta
    })


###########################################################################-----blog_details_page------###########################################

def blog_detail(request, slug):
    meta = get_meta('blog_detail')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    social_media_links = SocialMediaLink.objects.first()
    
    # Hot news articles with active_status=True
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)

    # Categories and popular articles
    category_article_counts = CategoryArticleCount.objects.all()
    popular_categories = Category.objects.filter(popular=True)
    popular_articles = Article.objects.filter(popular=True, active_status=True).order_by('-article_uploaded_date')[:10]
    recent_articles = Article.objects.filter(active_status=True).order_by('-article_uploaded_date')[:10]

    # Get the article by slug, ensure active_status=True
    article = get_object_or_404(Article, article_slug=slug, active_status=True)

    # Increment the views count
    article.views += 1
    article.save()

    # Related articles with active_status=True
    related_articles = Article.objects.filter(
        categories__in=article.categories.all(),
        active_status=True
    ).exclude(id=article.id).distinct().order_by('-article_uploaded_date')[:20]

    # Fetch active comments
    comments = article.comments.filter(active=True)
    comment_count = comments.count()
    new_comment = None
    success_message = None

    if request.method == 'POST':
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        data = urllib.parse.urlencode(values).encode()
        req = urllib.request.Request(url, data=data)
        response = urllib.request.urlopen(req)
        result = json.loads(response.read().decode())

        if result['success']:
            name = request.POST.get('name')
            email = request.POST.get('email')
            body = request.POST.get('body')
            
            if name and email and body:
                new_comment = Comment(
                    article=article,
                    name=name,
                    email=email,
                    body=body,
                )
                new_comment.save()

                telegram_settings = TelegramSettings.objects.all()
                bot_token = settings.TELEGRAM_BOT_TOKEN

                # Format the message with emojis and markdown
                telegram_message = (
                    f"📝 *New Comment on Blog:*\n\n"
                    f"🔗 *Blog Title:* {article.article_title_h1}\n"
                    f"👤 *Name:* {name}\n"
                    f"📧 *Email:* {email}\n"
                    f"💬 *Comment:* {body}\n\n"
                    "✅ *Please review and approve if appropriate.*"
                )

                # Send notifications in the background using threads
                chat_ids = [setting.chat_id for setting in telegram_settings]
                threading.Thread(target=send_comment_notifications_in_background, args=(telegram_message, bot_token, chat_ids)).start()

                messages.success(request, 'Your comment has been submitted and will appear after approval.')
                return HttpResponseRedirect(reverse('blog_detail', args=[slug]))
        else:
            messages.warning(request, 'reCAPTCHA verification failed. Please try again.')

    return render(request, 'blog-detail.html', {
        'hot_news_articles': hot_news_articles,
        'article': article,
        'category_article_counts': category_article_counts,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'categories': categories,
        'related_articles': related_articles,
        'comments': comments,
        'comment_count': comment_count,
        'new_comment': new_comment,
        'meta': meta,
        'success_message': success_message
    })

def send_telegram_notification_comment(message, bot_token, chat_id):
    send_text = f'https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={urllib.parse.quote(message)}&parse_mode=Markdown'
    requests.get(send_text)

def send_comment_notifications_in_background(message, bot_token, chat_ids):
    for chat_id in chat_ids:
        thread = threading.Thread(target=send_telegram_notification_comment, args=(message, bot_token, chat_id))
        thread.start()

##########################################################################----magazine------######################################################

def magazine_flipbook(request, article_slug):
    article = get_object_or_404(Article, article_slug=article_slug)  

    if not article.magazine_iframe:
        return render(request, "404.html")  # Show 404 if no PDF

    return render(request, "magazine_flipbook.html", {"article": article})


##########################################################################-----video-page-----#####################################################

def video(request):
    meta = get_meta('video')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)
    social_media_links = SocialMediaLink.objects.first()

    videos = Video.objects.all().order_by('-id')[:20]
    recent_videos = Video.objects.all().order_by('-id')[:10]
    popular_videos = Video.objects.filter(popular=True).order_by('-id')[:10]
    return render(request, 'video.html',{'social_media_links':social_media_links,'videos': videos, 'recent_videos':recent_videos,'popular_videos':popular_videos,
                                         'hot_news_articles':hot_news_articles,'categories':categories, 'meta': meta})

#####################################################################--load--more--#################################################################

def load_more_videos(request):
    offset = int(request.GET.get('offset', 20))
    limit = 10
    videos = Video.objects.all()[offset:offset+limit]
    video_data = [
        {
            'video_link': video.video_link,
            'image_url': video.image.url,
            'title': video.title,
            'description': video.description,
            'category': video.category,
            'date': video.date.strftime("%d %B %Y"),
            'profile_image_url': video.profile_image.url,
            'profile_name': video.profile_name,
        } for video in videos
    ]
    return JsonResponse({'videos': video_data,})

##################################################-search--page###########################################################

from datetime import timedelta

def search(request):
    meta = get_meta('search_result')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    
    query = request.GET.get('se', '')
    if query:
        results = Article.objects.filter(article_title_h1__icontains=query, active_status=True)
    else:
        results = Article.objects.none()

    # Popular articles with active_status=True
    popular_articles = Article.objects.filter(popular=True, active_status=True).order_by('-article_uploaded_date')[:10]

    # Recent articles with active_status=True
    recent_articles = Article.objects.filter(active_status=True).order_by('-article_uploaded_date')[:10]

    # Hot news articles with active_status=True
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)

    # Popular categories
    popular_categories = Category.objects.filter(popular=True)

    # Social media links
    social_media_links = SocialMediaLink.objects.first()

    return render(request, 'search_results.html', {
        'results': results,
        'query': query,
        'popular_articles': popular_articles,
        'recent_articles': recent_articles,
        'hot_news_articles': hot_news_articles,
        'category_article_counts': CategoryArticleCount.objects.all(),
        'popular_categories': popular_categories,
        'social_media_links': social_media_links,
        'categories': categories,
        'meta': meta
    })


########################################################--subscription--#########################################################################


def subscribe(request):
    today = timezone.now().date()
    last_submission_date = request.session.get('last_submission_date')

    if last_submission_date and last_submission_date == str(today):
        messages.error(request, 'You have already submitted the form today. If you want to add another email, please wait until tomorrow.')
        return redirect(request.META.get('HTTP_REFERER', 'index'))

    if request.method == 'POST':
        email = request.POST.get('email', '').strip()

        if not email:
            messages.error(request, 'Email field cannot be empty.')
        else:
            if Subscription.objects.filter(email=email).exists():
                messages.error(request, 'This email has already been submitted.')
            else:
                Subscription.objects.create(email=email)
                messages.success(request, 'We will be in touch soon!')
                request.session['last_submission_date'] = str(today)
                request.session.set_expiry(86400) 
        
        return redirect(request.META.get('HTTP_REFERER', 'index'))

    return redirect('index')

##########################################################################################################################

def interviews_response(request):
    if request.method == 'POST':
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        data = urllib.parse.urlencode(values).encode()
        req = urllib.request.Request(url, data=data)
        try:
            response = urllib.request.urlopen(req)
            result = json.loads(response.read().decode())
        except Exception as e:
            messages.error(request, 'Error verifying reCAPTCHA. Please try again later.')
            return render(request, 'submit_interview.html')

        if result.get('success'):
            article = InterviewArticle(
                name=request.POST.get('name'),
                website_URL=request.POST.get('website_URL'),
                facebook_URL=request.POST.get('facebook_URL'),
                linkedin_URL=request.POST.get('linkedin_URL'),
                instagram_URL=request.POST.get('instagram_URL'),
                twitter_URL=request.POST.get('twitter_URL'),
                background_business=request.POST.get('background_business'),
                business_focus=request.POST.get('business_focus'),
                growth_plans=request.POST.get('growth_plans'),
                yearly_impact=request.POST.get('yearly_impact'),
                startup_advice=request.POST.get('startup_advice'),
                image1=request.FILES.get('image1'),
                image2=request.FILES.get('image2'),
                image3=request.FILES.get('image3'),
            )
            article.save() 
            telegram_settings = TelegramSettings.objects.all()
            bot_token = settings.TELEGRAM_BOT_TOKEN

            telegram_message = (
                f"📝 *New Interview Submission:*\n\n"
                f"👤 *Name:* {article.name}\n"
                f"🔗 *Website URL:* {article.website_URL if article.website_URL else 'N/A'}\n"
                f"📘 *Facebook URL:* {article.facebook_URL if article.facebook_URL else 'N/A'}\n"
                f"💼 *LinkedIn URL:* {article.linkedin_URL if article.linkedin_URL else 'N/A'}\n"
                f"📸 *Instagram URL:* {article.instagram_URL if article.instagram_URL else 'N/A'}\n"
                f"🐦 *Twitter (X) URL:* {article.twitter_URL if article.twitter_URL else 'N/A'}\n\n"
                f"💬 *Background and Business Overview:* {article.background_business}\n\n"
                "✅ *Please review and approve if appropriate.*"
            )
            chat_ids = [setting.chat_id for setting in telegram_settings]
            threading.Thread(target=send_comment_notifications_in_background, args=(telegram_message, bot_token, chat_ids)).start()
            return redirect('thank_you_page')  
        else:
            messages.warning(request, 'reCAPTCHA verification failed. Please try again.')
            return render(request, 'submit_interview.html')

    return render(request, 'submit_interview.html')


def thank_you(request):
    return render(request, 'thankyou.html')

#############################################################################################################################################

def custom_404(request, exception):
    return render(request, '404.html', {}, status=404)

def custom_500(request):
    return render(request, '500.html', status=500)


#########################################-robots.txt-#######################################################################

def robots_txt(request):
    content = """
    User-agent: *
    Disallow: /admin/
    Allow: /

    Sitemap: https://www.gulfarticles.com/sitemap.xml
    """
    return HttpResponse(content, content_type="text/plain")

#########################################-magazine-#######################################################################

def magazine_list(request):
    meta = get_meta('magazine_list')
    categories = CategoryArticleCount.objects.exclude(category_name="Exclusive-Features")
    social_media_links = SocialMediaLink.objects.first()
    five_days_ago = timezone.now() - timedelta(days=5)
    hot_news_articles = Article.objects.filter(hot_news=True, article_uploaded_date__gte=five_days_ago, active_status=True)

    magazine = Article.objects.filter(
        active_status=True,
        magazine_pdf__isnull=False,
        magazine_thumbnail__isnull=False,
        magazine_name__isnull=False
    ).order_by('-id')

    paginator = Paginator(magazine, 1)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)

    print(f"Loading page {page_number} with {page_obj.object_list.count()} articles")

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        articles_html = ""
        for article in page_obj:
            articles_html += f"""
            <div class="col-lg-3 col-md-4 col-sm-6 col-12 d-flex flex-column align-items-center mb-4">
            <div class="magazinecards" style=" min-height: 540px;">
                <div class="magazine-card w-100">
                    <a href="/magazine/{article.article_slug}">
                        <img src="{article.magazine_thumbnail.url}" alt="{article.magazine_name}">
                    </a>
                </div>
                <h2 style="
                    font-size: 16px;
                    font-weight: 600;
                    color: #2c2c2c;
                    text-align: center;
                    margin-top: -5px;
                    margin-bottom: 10px;
                    padding: 0 10px;
                    font-family: 'Outfit', sans-serif;
                    position: relative;
                    min-height: 48px;
                ">
                    { article.article_title_h1 }
                </h2>
                <div
                    style="width: 30%; height: 4px; background-color: #e93314; margin: 5px auto 10px; border-radius: 2px;">
                </div>
             </div>   
            </div>
            """
        has_next = page_obj.has_next()

        print(f"Has next page: {has_next}")

        return JsonResponse({'html': articles_html, 'has_next': has_next})
    return render(request, 'magazine-list.html', {
        'social_media_links': social_media_links,
        'categories': categories,
        'meta': meta,
        'hot_news_articles': hot_news_articles,
        'magazine': page_obj,
    })
